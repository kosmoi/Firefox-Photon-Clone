# Firefox-Photon-Clone

This is a tool by @pellaeon [https://github.com/pellaeon], a BIT modyfied by me and with a new installation guide.


# Changes from original

Link to the Original: https://github.com/pellaeon/firefox-91plus-photon-userchrome

In fact, I only have change the size of the single tabs on the top corner.
Mainly, I created this project, that I can find this stuff easily and to create a installation guide. 

The main work (99.9 %) is made by pellaeon!

-----------------------------------------------------------------


# Installation
Guide for the Firefox-Photon-Clone of pellaeon (and Kosmoi)

1. Download the repository and unpack it.

2. Open the 'about:config' site in firefox and set the 'toolkit.legacyUserProfileCustomizations.stylesheets' preference to 'true'

3. Open the 'about:support' site and the 'Profile Directory' folder, which is declared in the Table in the 'about:sopport' page.

4. Copy the 'chrome' folder of the repository in the 'Profile Directory' folder

5. Click on the 'Clear startup chache' button in the box at the top right corner in the about:support and restart the firefox browser.
